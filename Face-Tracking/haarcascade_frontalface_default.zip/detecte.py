import cv2
import numpy

def init():
    if cap.isOpened():
        res, img = cap.read()
        h,w,k = img.shape
        return h/2,w/2

def Done():
    while cap.isOpened():
        res, img = cap.read()
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        Scan = face.detectMultiScale(gray,scaleFactor=1.1,minNeighbors=3)  # detectMultiScale(图片，前后两个窗口的比例系数，组成检测目标的相邻的最小比例系数。)
        if len(Scan)>0:
            for (x,y,w,h) in Scan:
                cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)  #依靠对角线来定矩形
                print(x+w/2, y+h/2)
        cv2.imshow("CaptureFace",img)

        key = cv2.waitKey(50) & 0xff
        if key == 27:  #ESC的ASCALL码是27
            break
    cap.release()
    cv2.destroyAllWindows()

# def Err(x_center, y_center, x_now, y_now):



if __name__ == '__main__':
    cap = cv2.VideoCapture(0)
    face = cv2.CascadeClassifier(r'haarcascade_frontalface_default.xml')
    cx,cy = init()
    print("中心:",end=' ')
    print(cy,cx)
    Done()
